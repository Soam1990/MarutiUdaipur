# Mystic Solution website: Base44 version

This is a rebuild of mysticadvertisement.com (from the WPvivid backup of mystic.digipixstudio.com) as React + Tailwind code for Base44. All text, images, colours (#C52027 / #F45B63), fonts (Poppins + Inter), page structure and links come from the original Elementor site.

## What's inside

```
src/
  Layout.jsx                     Header (with Services dropdown + mobile menu), footer, WhatsApp button
  pages/
    Home.jsx  Services.jsx  OurWork.jsx  AboutUs.jsx  Contact.jsx  DigitalMarketing.jsx
    Printing.jsx  OutdoorAdvertising.jsx  SignageInShopBranding.jsx
    CorporateEventsStoreLaunches.jsx  MobileHoardings.jsx  NewspaperInsertions.jsx
  components/site/
    siteData.js          Phone, email, WhatsApp, socials, nav, service cards, galleries, IMG_BASE
    serviceDetails.js    Full text of the six service detail pages
    ServiceDetailPage.jsx  Shared layout for those six pages
    ui.jsx               Buttons, banners, cards, gallery lightbox, experience badge
    Icons.jsx            Inline SVG icons (no extra packages)
entities/
  ContactSubmission.json  Database table for the contact form
public/images/            58 optimised WebP images (8 MB, down from ~340 MB in the backup)
```

The code uses only what every Base44 app already has: `react`, `react-router-dom` (`Link`, `useLocation`), Tailwind, `createPageUrl` from `@/utils` and the `base44` client from `@/api/base44Client`. You don't need to install any extra npm packages.

## Option A: Base44 with GitHub sync (recommended)

1. In Base44, create a new app (or open an existing empty one) and connect it to GitHub.
2. Clone the repo, then copy in `src/Layout.jsx`, `src/pages/*`, `src/components/site/*` and `public/images/*`. Keep the folder names your Base44 repo already uses.
3. Add the `ContactSubmission` entity. Copy `entities/ContactSubmission.json` into the repo's entities folder, or create it in **Dashboard → Data** with these fields: name, phone (required), email, service, message, source_page.
4. Commit and push. Base44 syncs the code.
5. In app settings, set **Home** as the main/landing page.

## Option B: Base44 editor only (no GitHub)

1. **Images:** pages can only load images from a URL. Upload the files in `public/images` somewhere that serves them from one folder URL (Base44 file storage, Cloudflare R2/S3, or your own hosting). Then set `IMG_BASE` at the top of `components/site/siteData.js` to that folder URL, ending in `/`.
2. Create the `ContactSubmission` entity (fields as above).
3. In the code editor, create each file under `components/site/` and paste in its content. Do the same for `Layout.jsx` and each page in `pages/`, using exactly the same page names, because links use those names.
4. Set **Home** as the main page.

## Contact form

Submissions are saved to the `ContactSubmission` entity. You can see them in Base44 under **Dashboard → Data**. If saving fails, the visitor gets a ready-filled WhatsApp link to send the enquiry instead. The dropdown options match the original WPForms form.

To get an email for each new enquiry, add a Base44 automation or backend function on `ContactSubmission` create that sends to marutimysticsolution@gmail.com.

## Editing content

* **Phone, email, WhatsApp number, social links, menu, service cards, gallery images:** `components/site/siteData.js`
* **Service detail page text:** `components/site/serviceDetails.js`
* **Section copy on Home, About, Contact:** the matching file in `pages/`

## Small changes from the WordPress site

* Fixed the "Get Quote on Whatrsapp" typo on every button.
* The footer copyright year now updates automatically.
* The full-screen popup that appears on the live site's first load is left out.
* The contact form saves to Base44 instead of WPForms.
