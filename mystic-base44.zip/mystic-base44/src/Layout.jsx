import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { NAV, FOOTER_LINKS, BRAND, img } from "@/components/site/siteData";
import { Container } from "@/components/site/ui";
import { ChevronDownIcon, MenuIcon, CloseIcon, WhatsAppIcon } from "@/components/site/Icons";

const GLOBAL_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Poppins:ital,wght@0,500;0,600;0,700;1,600&display=swap');
.ms-site { font-family: 'Inter', system-ui, sans-serif; color: #737373; }
.ms-heading { font-family: 'Poppins', system-ui, sans-serif; }
@keyframes ms-spin { to { transform: rotate(360deg); } }
.ms-spin { animation: ms-spin 18s linear infinite; transform-origin: 50% 50%; }
@keyframes ms-marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
.ms-marquee { animation: ms-marquee 28s linear infinite; }
@keyframes ms-fade-up { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: none; } }
.ms-fade-up { animation: ms-fade-up .8s ease-out both; }
html { scroll-behavior: smooth; }
`;

function isActive(item, currentPageName) {
  if (item.page === currentPageName) return true;
  return (item.children || []).some((c) => c.page === currentPageName);
}

function Header({ currentPageName }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMobileOpen(false);
    setServicesOpen(false);
  }, [location.pathname]);

  return (
    <header className="relative z-50 bg-white">
      <Container className="flex h-[96px] items-center justify-between gap-6">
        <Link to={createPageUrl("Home")} className="shrink-0" aria-label={`${BRAND.name} home`}>
          <img src={img(BRAND.logo)} alt={BRAND.legalName} className="h-[54px] w-auto md:h-[62px]" />
        </Link>

        <nav className="hidden flex-1 items-center justify-center gap-11 lg:flex" aria-label="Main">
          {NAV.map((item) =>
            item.children ? (
              <div key={item.label} className="group relative">
                <Link
                  to={createPageUrl(item.page)}
                  className={`flex items-center gap-1 py-8 text-[15px] font-medium transition-colors hover:text-[#C52027] ${
                    isActive(item, currentPageName) ? "text-[#C52027]" : "text-[#272727]"
                  }`}
                >
                  {item.label}
                  <ChevronDownIcon size={14} />
                </Link>
                <div className="invisible absolute left-1/2 top-full w-[280px] -translate-x-1/2 translate-y-2 rounded-[10px] bg-white py-3 opacity-0 shadow-[0_15px_40px_rgba(0,0,0,0.12)] transition-all duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                  {item.children.map((c) => (
                    <Link
                      key={c.page}
                      to={createPageUrl(c.page)}
                      className={`block px-6 py-2.5 text-[14px] transition-colors hover:bg-[#FFF6F6] hover:text-[#C52027] ${
                        c.page === currentPageName ? "text-[#C52027]" : "text-[#272727]"
                      }`}
                    >
                      {c.label}
                    </Link>
                  ))}
                </div>
              </div>
            ) : (
              <Link
                key={item.label}
                to={createPageUrl(item.page)}
                className={`py-8 text-[15px] font-medium transition-colors hover:text-[#C52027] ${
                  isActive(item, currentPageName) ? "text-[#C52027]" : "text-[#272727]"
                }`}
              >
                {item.label}
              </Link>
            )
          )}
        </nav>

        <div className="flex items-center gap-4">
          <a
            href={BRAND.phoneHref}
            className="hidden rounded-full bg-[#F45B63] px-11 py-3 text-[14px] font-semibold text-[#272727] transition-colors hover:bg-[#C52027] hover:text-white sm:inline-block"
          >
            Call Now
          </a>
          <button
            type="button"
            className="text-[#272727] lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <MenuIcon />
          </button>
        </div>
      </Container>

      {/* Mobile off-canvas menu */}
      <div
        className={`fixed inset-0 z-[90] bg-black/40 transition-opacity lg:hidden ${
          mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={() => setMobileOpen(false)}
      />
      <aside
        className={`fixed right-0 top-0 z-[95] flex h-full w-[86%] max-w-[360px] flex-col overflow-y-auto bg-white shadow-2xl transition-transform duration-300 lg:hidden ${
          mobileOpen ? "translate-x-0" : "translate-x-full"
        }`}
        aria-hidden={!mobileOpen}
      >
        <div className="flex items-center justify-between border-b border-[#DDE0E0] px-6 py-5">
          <img src={img(BRAND.logo)} alt={BRAND.legalName} className="h-[46px] w-auto" />
          <button type="button" onClick={() => setMobileOpen(false)} aria-label="Close menu" className="text-[#272727]">
            <CloseIcon />
          </button>
        </div>
        <nav className="flex flex-col px-6 py-4" aria-label="Mobile">
          {NAV.map((item) => (
            <div key={item.label} className="border-b border-[#F0F0F0]">
              <div className="flex items-center justify-between">
                <Link
                  to={createPageUrl(item.page)}
                  className={`block py-3.5 text-[15px] font-medium ${
                    isActive(item, currentPageName) ? "text-[#C52027]" : "text-[#272727]"
                  }`}
                >
                  {item.label}
                </Link>
                {item.children && (
                  <button
                    type="button"
                    onClick={() => setServicesOpen((v) => !v)}
                    className="p-2 text-[#272727]"
                    aria-label="Toggle services"
                  >
                    <ChevronDownIcon className={`transition-transform ${servicesOpen ? "rotate-180" : ""}`} />
                  </button>
                )}
              </div>
              {item.children && servicesOpen && (
                <div className="pb-3 pl-4">
                  {item.children.map((c) => (
                    <Link
                      key={c.page}
                      to={createPageUrl(c.page)}
                      className={`block py-2 text-[14px] ${c.page === currentPageName ? "text-[#C52027]" : "text-[#737373]"}`}
                    >
                      {c.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
        <div className="mt-auto px-6 pb-8">
          <a
            href={BRAND.phoneHref}
            className="block rounded-full bg-[#F45B63] px-6 py-3 text-center text-[14px] font-semibold text-[#272727]"
          >
            Call Now
          </a>
        </div>
      </aside>
    </header>
  );
}

function Footer() {
  return (
    <footer className="bg-[#F6F5FD]">
      <Container className="flex flex-col items-center pb-6 pt-16 text-center">
        <Link to={createPageUrl("Home")} aria-label={`${BRAND.name} home`}>
          <img src={img(BRAND.logo)} alt={BRAND.legalName} className="h-[90px] w-auto" />
        </Link>
        <div className="mt-5 h-[2px] w-[34px] bg-[#7C3AED]" />
        <p className="mt-6 max-w-[560px] text-[14px] leading-[1.6] text-[#737373]">
          We provide complete branding, printing, outdoor advertising, and digital marketing solutions for businesses
          looking to grow and stand out.
        </p>
        <nav className="mt-6 flex flex-wrap justify-center gap-x-8 gap-y-2" aria-label="Footer">
          {FOOTER_LINKS.map((l) => (
            <Link
              key={l.label}
              to={createPageUrl(l.page)}
              className="text-[13px] font-medium text-[#272727] transition-colors hover:text-[#C52027]"
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="mt-8 w-full border-t border-[#DDE0E0] pt-6 text-[12px] text-[#737373]">
          © {new Date().getFullYear()} {BRAND.name}. All rights reserved.
        </div>
      </Container>
    </footer>
  );
}

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="ms-site min-h-screen bg-white antialiased">
      <style>{GLOBAL_CSS}</style>
      <Header currentPageName={currentPageName} />
      <main>{children}</main>
      <Footer />
      <a
        href={BRAND.whatsappHref}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 right-5 z-[80] flex h-[54px] w-[54px] items-center justify-center rounded-full bg-[#25D366] text-white shadow-[0_6px_20px_rgba(0,0,0,0.25)] transition-transform hover:scale-110"
        aria-label="WhatsApp us"
        title="WhatsApp us"
      >
        <WhatsAppIcon size={30} />
      </a>
    </div>
  );
}
