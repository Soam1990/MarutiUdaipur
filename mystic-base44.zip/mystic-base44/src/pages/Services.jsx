import React from "react";
import { OUTDOOR_SERVICES, DIGITAL_SERVICES, img } from "@/components/site/siteData";
import { Container, SectionTag, ImageBoxCard, QuoteButtons, ServiceGroupHeading } from "@/components/site/ui";

export default function Services() {
  // The Services page shows five digital cards (Bulk SMS is only on the Digital Marketing page).
  const digital = DIGITAL_SERVICES.filter((s) => s.title !== "Bulk SMS");

  return (
    <>
      <section className="pb-10 pt-4">
        <Container>
          <div className="grid gap-10 rounded-[18px] bg-[#F6F7F7] p-7 md:p-12 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <SectionTag>Our Services</SectionTag>
              <h1 className="ms-heading mt-4 text-[30px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[38px]">
                Building Brands That Make an Impact
              </h1>
              <img
                src={img("website-images-21.webp")}
                alt="Retail signage by Maruti Mystic Solution"
                className="mt-6 h-[220px] w-full rounded-[14px] object-cover"
              />
            </div>
            <div className="space-y-5 text-[14px] leading-[1.7] lg:pt-2">
              <p className="text-[15px]">
                Maruti Mystic Solution provides complete{" "}
                <strong className="text-[#272727]">
                  branding, printing, outdoor advertising, and digital marketing solutions
                </strong>{" "}
                to help businesses build visibility and connect with their customers.
              </p>
              <p>
                From <strong className="text-[#272727]">visiting cards, brochures, flex and vinyl printing</strong> to{" "}
                <strong className="text-[#272727]">
                  ACP signage, acrylic letters, mobile hoardings, unipoles, and in-shop branding
                </strong>
                , we handle your offline branding needs with quality and creativity.
              </p>
              <p>
                Our digital services include{" "}
                <strong className="text-[#272727]">
                  social media marketing, Google Ads, website designing, logo designing, and Bulk SMS
                </strong>
                , giving your business the tools to grow both offline and online.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <section className="py-14">
        <Container>
          <ServiceGroupHeading title="Outdoor Marketing" subtitle="Make Your Brand Impossible to Miss" />
          <div className="mt-12 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {OUTDOOR_SERVICES.map((s) => (
              <ImageBoxCard key={s.title} title={s.title} text={s.text} image={s.servicesImage || s.image} page={s.page} />
            ))}
          </div>
          <QuoteButtons className="mt-12" />
        </Container>
      </section>

      <section className="py-14">
        <Container>
          <ServiceGroupHeading title="Digital Marketing" subtitle="Build Your Brand in the Digital World" />
          <div className="mt-12 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {digital.map((s) => (
              <ImageBoxCard key={s.title} {...s} page="DigitalMarketing" />
            ))}
          </div>
          <QuoteButtons className="mt-12" />
        </Container>
      </section>
    </>
  );
}
