import React from "react";
import { DIGITAL_SERVICES } from "@/components/site/siteData";
import { Container, PageHero, ImageBoxCard, QuoteButtons, ServiceGroupHeading } from "@/components/site/ui";

export default function DigitalMarketing() {
  return (
    <>
      <PageHero tag="Services" title="Digital Marketing" image="ipad-mockup-apple-business-39559-39559-scaled.webp" />
      <section className="py-20">
        <Container>
          <ServiceGroupHeading title="Digital Marketing" subtitle="Build Your Brand in the Digital World" />
          <div className="mt-12 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {DIGITAL_SERVICES.map((s) => (
              <ImageBoxCard key={s.title} {...s} />
            ))}
          </div>
          <QuoteButtons className="mt-12" />
        </Container>
      </section>
    </>
  );
}
