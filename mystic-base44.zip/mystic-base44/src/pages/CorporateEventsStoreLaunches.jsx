import React from "react";
import ServiceDetailPage from "@/components/site/ServiceDetailPage";

export default function CorporateEventsStoreLaunches() {
  return <ServiceDetailPage slug="CorporateEventsStoreLaunches" />;
}
