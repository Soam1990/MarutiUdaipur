import React from "react";
import ServiceDetailPage from "@/components/site/ServiceDetailPage";

export default function SignageInShopBranding() {
  return <ServiceDetailPage slug="SignageInShopBranding" />;
}
