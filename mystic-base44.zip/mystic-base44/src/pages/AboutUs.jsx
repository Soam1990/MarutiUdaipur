import React from "react";
import { img } from "@/components/site/siteData";
import { Container, PageHero, ExperienceBadge } from "@/components/site/ui";

const B = ({ children }) => <strong className="font-semibold text-[#272727]">{children}</strong>;

export default function AboutUs() {
  return (
    <>
      <PageHero tag="About Us" title="Take The Next Step Into Digital Success" image="website-images-2.webp" />

      <section className="py-20">
        <Container className="grid items-center gap-14 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="relative pl-8 pt-6 lg:pl-12">
            <img
              src={img("796f54b6-ae19-42a7-9df3-dec9c364d6a4.webp")}
              alt="Hoarding campaign by Maruti Mystic Solution"
              className="h-[340px] w-full rounded-[18px] object-cover sm:h-[440px]"
            />
            <ExperienceBadge years={8} className="absolute -left-2 -top-2 sm:-left-4 sm:-top-4" />
          </div>
          <div>
            <h2 className="ms-heading text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[40px]">
              Building Brands. Creating Visibility. Driving Growth.
            </h2>
            <div className="mt-6 space-y-4 text-[14px] leading-[1.75]">
              <p>
                Established in <B>2018</B>, Maruti Mystic Solution is a full-service{" "}
                <B>branding, printing, outdoor advertising, and digital marketing company</B> based in Udaipur,
                Rajasthan. We help businesses create a strong presence, attract customers, and communicate their brand
                effectively across both offline and digital channels.
              </p>
              <p>
                Our expertise covers everything from{" "}
                <B>
                  print solutions and creative design to outdoor advertising, signage, in-shop branding, mobile
                  hoardings, and digital marketing.
                </B>{" "}
                Whether you need a professional visiting card, eye-catching hoarding, complete store branding, or a
                digital campaign, we bring the right creative and marketing solutions together under one roof.
              </p>
              <p>
                We believe great marketing is more than just being visible—it is about <B>being remembered.</B> That’s
                why we combine creativity, quality, strategic thinking, and reliable execution to deliver solutions that
                match each client’s goals.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <section className="pb-24">
        <Container>
          <div className="mx-auto max-w-[820px] rounded-[18px] bg-[#F6F7F7] p-8 md:p-12">
            <h2 className="ms-heading text-[28px] font-semibold tracking-[-0.5px] text-[#272727] md:text-[34px]">
              What We Do
            </h2>
            <p className="mt-5 text-[14px] leading-[1.75]">
              Maruti Mystic Solution provides{" "}
              <B>complete branding, printing, outdoor advertising, and digital marketing solutions</B> for businesses of
              all sizes. From professional print materials, signage, ACP boards, acrylic letters, and in-shop branding
              to hoardings, mobile hoardings, and e-rickshaw advertising, we help businesses build a strong offline
              presence. Our digital marketing services, including social media marketing, SEO, Google Ads, Meta Ads,
              performance marketing, website design, and content creation, help brands grow and connect with customers
              online.
            </p>
          </div>
        </Container>
      </section>
    </>
  );
}
