import React from "react";
import {
  BRAND,
  SOCIALS,
  OUTDOOR_SERVICES,
  CLIENT_LOGOS,
  HOME_GALLERY,
  img,
} from "@/components/site/siteData";
import {
  Container,
  SectionTag,
  PillButton,
  ExperienceBadge,
  ImageBoxCard,
  CtaBand,
  Gallery,
} from "@/components/site/ui";
import { InstagramIcon, LinkedinIcon, PlusIcon, ToolsIcon, BadgeIcon, TeamIcon } from "@/components/site/Icons";

function Hero() {
  return (
    <section className="pb-16 pt-4">
      <Container className="grid items-center gap-10 lg:grid-cols-[1fr_1.05fr]">
        <div className="ms-fade-up">
          <h1 className="ms-heading text-[40px] font-semibold capitalize leading-[1.15] tracking-[-1.5px] text-black sm:text-[52px] lg:text-[58px]">
            Smart <em className="font-semibold text-[#C52027]">Advertising Solutions</em> For Real Business Growth
          </h1>
          <p className="mt-6 max-w-[520px] text-[15px] leading-[1.7] text-[#737373]">
            From printing and outdoor advertising to digital marketing, we help businesses build a strong brand presence
            both offline and online.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <PillButton page="Services" variant="red" size="lg">
              Discover More
            </PillButton>
            <PillButton page="Contact" variant="dark" size="lg">
              Contact Us
            </PillButton>
          </div>

          <div className="mt-16 flex items-center gap-3">
            <div className="h-px flex-1 bg-[#DDE0E0]" />
            <span className="h-2 w-2 bg-[#C52027]" />
          </div>
          <p className="mt-6 text-[16px] font-medium text-[#272727]">Follow Us:</p>
          <ul className="mt-4 flex flex-wrap gap-x-8 gap-y-3">
            {SOCIALS.map((s) => (
              <li key={s.href}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[13px] text-[#737373] underline underline-offset-2 transition-colors hover:text-[#C52027]"
                >
                  {s.type === "instagram" ? (
                    <InstagramIcon size={15} className="text-[#C52027]" />
                  ) : (
                    <LinkedinIcon size={14} className="text-[#C52027]" />
                  )}
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-[18px]">
            <img
              src={img("website-images-2.webp")}
              alt="Smart Point store branding by Maruti Mystic Solution"
              className="h-[460px] w-full object-cover sm:h-[600px] lg:h-[680px]"
            />
          </div>
          {/* Stats card sitting in a white notch at the bottom-left of the photo */}
          <div className="absolute bottom-0 left-0 rounded-tr-[26px] bg-white pr-3 pt-3">
            <div className="w-[300px] rounded-[18px] bg-[#F45B63] p-6 sm:w-[420px] sm:p-7">
              <h3 className="ms-heading text-[17px] font-semibold leading-[1.35] text-[#272727] sm:text-[20px]">
                We Drive Sustainable Digital Growth for Ambitious Brands
              </h3>
              <div className="mt-5 flex items-center gap-4">
                <div className="flex -space-x-3">
                  {["client-thumb-1.webp", "client-thumb-3.webp", "client-thumb-2.webp"].map((t) => (
                    <img
                      key={t}
                      src={img(t)}
                      alt=""
                      className="h-11 w-11 rounded-full border-2 border-white bg-white object-cover"
                    />
                  ))}
                  <span className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white bg-[#C52027] text-white">
                    <PlusIcon size={18} />
                  </span>
                </div>
                <div>
                  <div className="ms-heading text-[15px] font-semibold text-white">More than 500+</div>
                  <div className="text-[12px] text-white/90">Happy Clients</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

function WhoWeAre() {
  const features = [
    {
      icon: <ToolsIcon />,
      title: "Customized Branding Solutions",
      text: "From print materials to outdoor campaigns, we create solutions tailored to your brand, audience, and goals.",
    },
    {
      icon: <BadgeIcon />,
      title: "Reliable Execution",
      text: "Our experienced team handles every project with attention to quality, detail, and timely delivery.",
    },
    {
      icon: <TeamIcon />,
      title: "Build Your Brand Offline & Online",
      text: "From impactful outdoor advertising and professional printing to creative branding and digital marketing, Maruti Mystic Solution helps your business get noticed, connect with customers, and grow.",
    },
  ];
  return (
    <section className="py-16">
      <Container>
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div className="relative pl-6 pt-6">
            <img
              src={img("website-images-20.webp")}
              alt="Event branding by Maruti Mystic Solution"
              className="h-[380px] w-full rounded-[18px] object-cover sm:h-[480px]"
            />
            <ExperienceBadge years={8} className="absolute -left-2 -top-2 sm:-left-4 sm:-top-4" />
          </div>
          <div>
            <SectionTag>Who We Are</SectionTag>
            <h2 className="ms-heading mt-4 text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[44px]">
              Complete Branding Solutions for Your Business
            </h2>
            <p className="mt-6 text-[14px] leading-[1.7]">
              Since 2018, <strong className="text-[#272727]">Maruti Mystic Solution</strong> has been helping businesses
              build a strong and memorable presence through printing, branding, outdoor advertising, and digital
              marketing.
            </p>
            <p className="mt-4 text-[14px] leading-[1.7]">
              From business cards and brochures to hoardings, signage, in-shop branding, and digital campaigns, we bring
              creative ideas and reliable execution together under one roof.
            </p>
            <PillButton page="AboutUs" variant="pink" size="sm" className="mt-8">
              More About Us
            </PillButton>
          </div>
        </div>

        <div className="mt-16 grid gap-10 md:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="flex gap-5">
              <span className="flex h-[58px] w-[58px] shrink-0 items-center justify-center rounded-[12px] bg-[#C52027] text-white">
                {f.icon}
              </span>
              <div>
                <h3 className="ms-heading text-[17px] font-semibold text-[#272727]">{f.title}</h3>
                <p className="mt-2.5 text-[13px] leading-[1.65]">{f.text}</p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

function StandOut() {
  const logos = [...CLIENT_LOGOS, ...CLIENT_LOGOS];
  return (
    <section className="px-3 py-8 md:px-5">
      <div
        className="relative mx-auto max-w-[1340px] overflow-hidden rounded-[24px] bg-cover bg-center"
        style={{ backgroundImage: `url(${img("website-images-1.webp")})` }}
      >
        <div className="absolute inset-0 bg-black/25" />
        <div className="relative px-5 pb-10 pt-12 md:px-10 md:pt-20">
          <div className="max-w-[580px] rounded-[18px] bg-[#C52027]/85 p-8 text-white backdrop-blur-[2px] md:p-10">
            <h2 className="ms-heading text-[30px] font-semibold capitalize leading-[1.2] tracking-[-1px] md:text-[40px]">
              Make Your Brand Stand Out Everywhere
            </h2>
            <p className="mt-5 text-[14px] leading-[1.7] text-white/95">
              From <strong>printing and outdoor advertising to branding and digital marketing</strong>, Maruti Mystic
              Solution provides complete solutions to help your business get noticed, connect with customers, and grow.
            </p>
            <PillButton href={BRAND.phoneHref} variant="white" size="sm" className="mt-7">
              Call Now
            </PillButton>
          </div>

          <div className="mt-16 overflow-hidden border-y border-white/30 bg-white/10 py-8">
            <div className="ms-marquee flex w-max items-center gap-16">
              {logos.map((l, i) => (
                <img
                  key={l.name + i}
                  src={img(l.image)}
                  alt={l.name}
                  className="h-[56px] w-[150px] object-contain md:h-[80px] md:w-[180px]"
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function WhatWeOffer() {
  return (
    <section className="py-20">
      <Container>
        <div className="mx-auto max-w-[640px] text-center">
          <SectionTag center>What We Offer</SectionTag>
          <h2 className="ms-heading mt-4 text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[40px]">
            Complete Branding &amp; Advertising Solutions
          </h2>
        </div>
        <div className="mt-12 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {OUTDOOR_SERVICES.map((s) => (
            <ImageBoxCard key={s.title} {...s} />
          ))}
        </div>
        <div className="mt-12 text-center">
          <PillButton page="Services" variant="pink" size="sm">
            View All Services
          </PillButton>
        </div>
      </Container>
    </section>
  );
}

function WhyChooseUs() {
  return (
    <section className="bg-[#F6F7F7] py-24">
      <Container className="grid items-center gap-12 lg:grid-cols-[0.75fr_1.25fr]">
        <div>
          <SectionTag>Why Choose Us</SectionTag>
          <h2 className="ms-heading mt-4 text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[40px]">
            Your One-Stop Partner for Complete Branding &amp; Advertising
          </h2>
          <p className="mt-6 text-[14px] leading-[1.7]">
            At <strong className="text-[#272727]">Maruti Mystic Solution</strong>, we bring printing, branding, outdoor
            advertising, and digital marketing together to help businesses build a stronger presence.
          </p>
          <PillButton page="AboutUs" variant="pink" size="sm" className="mt-8">
            Discover More
          </PillButton>
        </div>

        <div
          className="grid overflow-hidden rounded-[18px] bg-cover bg-center sm:grid-cols-2"
          style={{ backgroundImage: `url(${img("website-images-21.webp")})` }}
        >
          <WhyCard
            className="bg-[#F45B63] sm:rounded-br-[18px] sm:border-b-[12px] sm:border-r-[12px] sm:border-[#F6F7F7]"
            title="Quality-First Execution"
            text="From printing to large-format branding, we focus on quality materials, creative work, and professional execution."
          />
          <WhyCard
            className="bg-black/45"
            title="Tailored Solutions"
            text="Every brand has different needs. We create customized solutions that fit your business, audience, and campaign goals."
          />
          <WhyCard
            className="bg-black/45"
            title="Complete Branding Support"
            text="From visiting cards and signage to hoardings, mobile advertising, and digital campaigns, we handle it all under one roof."
          />
          <WhyCard
            className="bg-[#C52027] sm:rounded-tl-[18px] sm:border-l-[12px] sm:border-t-[12px] sm:border-[#F6F7F7]"
            title="Reliable Service"
            text="We value your time and deliver projects with clear communication, attention to detail, and dependable support."
          />
        </div>
      </Container>
    </section>
  );
}

function WhyCard({ title, text, className = "" }) {
  return (
    <div className={`flex min-h-[250px] flex-col justify-center p-8 text-white ${className}`}>
      <h3 className="ms-heading text-[22px] font-semibold leading-[1.25]">{title}</h3>
      <p className="mt-3 text-[13px] leading-[1.65] text-white/95">{text}</p>
    </div>
  );
}

function FeaturedProjects() {
  return (
    <section className="py-20">
      <Container>
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <div className="max-w-[560px]">
            <SectionTag>Featured Project</SectionTag>
            <h2 className="ms-heading mt-4 text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[40px]">
              Creative Work That Makes an Impact
            </h2>
          </div>
          <div className="max-w-[560px] md:pb-2">
            <p className="text-[14px] leading-[1.7]">
              Explore selected projects by Maruti Mystic Solution, showcasing our expertise in{" "}
              <strong className="text-[#272727]">
                branding, printing, outdoor advertising, signage, events, and digital marketing
              </strong>
              .
            </p>
            <div className="mt-6 h-[3px] w-[90px] bg-[#C52027]" />
          </div>
        </div>
        <div className="mt-12">
          <Gallery images={HOME_GALLERY} />
        </div>
        <div className="mt-14 flex flex-col items-start justify-between gap-6 rounded-[14px] border border-dashed border-[#DDE0E0] bg-[#F6F7F7] px-8 py-8 md:flex-row md:items-center">
          <p className="max-w-[640px] text-[15px] leading-[1.6] text-[#4a4a4a]">
            Take a look at our recent branding, printing, outdoor advertising, signage, event, and digital marketing
            projects.
          </p>
          <PillButton page="OurWork" variant="pink" size="sm">
            View All Projects
          </PillButton>
        </div>
      </Container>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <Hero />
      <WhoWeAre />
      <StandOut />
      <WhatWeOffer />
      <WhyChooseUs />
      <CtaBand image="website-images-4.webp" />
      <FeaturedProjects />
    </>
  );
}
