import React from "react";
import ServiceDetailPage from "@/components/site/ServiceDetailPage";

export default function NewspaperInsertions() {
  return <ServiceDetailPage slug="NewspaperInsertions" />;
}
