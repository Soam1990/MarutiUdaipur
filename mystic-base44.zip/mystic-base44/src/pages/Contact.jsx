import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { BRAND, CONTACT_SERVICE_OPTIONS } from "@/components/site/siteData";
import { Container, PageHero, SectionTag, PillButton } from "@/components/site/ui";
import { PhoneIcon, MailIcon, WhatsAppIcon } from "@/components/site/Icons";

const EMPTY = { name: "", phone: "", email: "", service: CONTACT_SERVICE_OPTIONS[0], message: "" };

const inputCls =
  "w-full rounded-[30px] border border-[#DDE0E0] bg-white px-5 py-3 text-[14px] text-[#272727] outline-none transition focus:border-[#C52027] focus:ring-2 focus:ring-[#C52027]/15";

function whatsappLink(form) {
  const text = [
    `Hi ${BRAND.name}, I'd like a quote.`,
    form.name && `Name: ${form.name}`,
    form.phone && `Phone: ${form.phone}`,
    form.email && `Email: ${form.email}`,
    form.service && `Service: ${form.service}`,
    form.message && `Message: ${form.message}`,
  ]
    .filter(Boolean)
    .join("\n");
  return `${BRAND.whatsappHref}&text=${encodeURIComponent(text)}`;
}

function ContactForm() {
  const [form, setForm] = useState(EMPTY);
  const [status, setStatus] = useState("idle"); // idle | sending | sent | error
  const [lastSent, setLastSent] = useState(EMPTY);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!form.phone.trim()) return;
    setStatus("sending");
    try {
      // Saved to the ContactSubmission entity — view submissions in the Base44 dashboard → Data.
      await base44.entities.ContactSubmission.create({ ...form, source_page: "Contact" });
      setLastSent(form);
      setForm(EMPTY);
      setStatus("sent");
    } catch (err) {
      console.error("Contact form submission failed", err);
      setLastSent(form);
      setStatus("error");
    }
  };

  return (
    <form onSubmit={onSubmit} className="rounded-[18px] bg-[#F6F7F7] p-7 md:p-10" noValidate={false}>
      <div className="space-y-4">
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-medium text-[#272727]">Name</span>
          <input className={inputCls} value={form.name} onChange={set("name")} autoComplete="name" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-medium text-[#272727]">
            Contact No <span className="text-[#C52027]">*</span>
          </span>
          <input
            className={inputCls}
            value={form.phone}
            onChange={set("phone")}
            type="tel"
            required
            autoComplete="tel"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-medium text-[#272727]">Email</span>
          <input className={inputCls} value={form.email} onChange={set("email")} type="email" autoComplete="email" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-medium text-[#272727]">Service I Am Looking For</span>
          <select className={inputCls} value={form.service} onChange={set("service")}>
            {CONTACT_SERVICE_OPTIONS.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-medium text-[#272727]">Comment Or Message</span>
          <textarea
            className={`${inputCls} min-h-[110px] rounded-[20px]`}
            value={form.message}
            onChange={set("message")}
          />
        </label>
      </div>

      <button
        type="submit"
        disabled={status === "sending"}
        className="mt-6 rounded-full bg-[#C52027] px-8 py-3 text-[14px] font-semibold text-white transition-colors hover:bg-[#a51a20] disabled:opacity-60"
      >
        {status === "sending" ? "Sending…" : "Submit"}
      </button>

      {status === "sent" && (
        <p className="mt-5 rounded-[12px] bg-[#e9f8ef] px-5 py-3 text-[14px] text-[#1d6b3a]" role="status">
          Thanks for contacting us! We will be in touch with you shortly.
        </p>
      )}
      {status === "error" && (
        <p className="mt-5 rounded-[12px] bg-[#FFF6F6] px-5 py-3 text-[14px] text-[#C52027]" role="alert">
          Sorry, we couldn’t send your message right now.{" "}
          <a href={whatsappLink(lastSent)} target="_blank" rel="noopener noreferrer" className="font-semibold underline">
            Send it on WhatsApp instead
          </a>{" "}
          or call us on {BRAND.phoneDisplay}.
        </p>
      )}
    </form>
  );
}

function InfoRow({ icon, title, value, href }) {
  return (
    <a href={href} className="group flex items-center justify-between gap-5 py-6">
      <div>
        <div className="ms-heading text-[17px] font-semibold text-[#272727]">{title}</div>
        <div className="mt-1 break-all text-[14px] text-[#737373] transition-colors group-hover:text-[#C52027]">
          {value}
        </div>
      </div>
      <span className="flex h-[64px] w-[64px] shrink-0 items-center justify-center rounded-[12px] bg-[#C52027] text-white">
        {icon}
      </span>
    </a>
  );
}

export default function Contact() {
  return (
    <>
      <PageHero
        tag="Contact"
        title="Let’s Talk & Build Better Business Together"
        image="g1035eae7962c490fa70bc3317fb033f1ed9ecdb73c8d32d1fe5bd433669.webp"
      />

      <section className="py-20">
        <Container className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          <div>
            <SectionTag>Get in touch</SectionTag>
            <h2 className="ms-heading mt-4 text-[32px] font-semibold leading-[1.2] tracking-[-1px] text-[#272727] md:text-[40px]">
              Get in touch, let us know how we can help
            </h2>
            <div className="mt-8 h-px bg-[#DDE0E0]" />
            <InfoRow icon={<PhoneIcon size={26} />} title="Let's Talk" value={BRAND.phoneDisplay} href={BRAND.phoneHref} />
            <div className="h-px bg-[#DDE0E0]" />
            <InfoRow icon={<MailIcon size={26} />} title="Email" value={BRAND.email} href={`mailto:${BRAND.email}`} />
            <div className="h-px bg-[#DDE0E0]" />
            <PillButton href={BRAND.whatsappHref} variant="whatsapp" className="mt-8" icon={<WhatsAppIcon size={17} />}>
              Get Quote
            </PillButton>
          </div>
          <ContactForm />
        </Container>
      </section>
    </>
  );
}
