import React from "react";
import ServiceDetailPage from "@/components/site/ServiceDetailPage";

export default function MobileHoardings() {
  return <ServiceDetailPage slug="MobileHoardings" />;
}
