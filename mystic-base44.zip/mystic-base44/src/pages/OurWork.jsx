import React from "react";
import { PORTFOLIO_GALLERY } from "@/components/site/siteData";
import { Container, PageHero, SectionTag, Gallery, QuoteButtons, CtaBand } from "@/components/site/ui";

export default function OurWork() {
  return (
    <>
      <PageHero tag="Our Work" title="Creative Work That Makes an Impact" image="image-18.webp" />

      <section className="py-20">
        <Container>
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
            <div className="max-w-[560px]">
              <SectionTag>Featured Project</SectionTag>
              <h2 className="ms-heading mt-4 text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] text-[#272727] md:text-[40px]">
                Creative Work That Makes an Impact
              </h2>
            </div>
            <div className="max-w-[560px] md:pb-2">
              <p className="text-[14px] leading-[1.7]">
                Explore selected projects by Maruti Mystic Solution, showcasing our expertise in{" "}
                <strong className="text-[#272727]">
                  branding, printing, outdoor advertising, signage, events, and digital marketing
                </strong>
                .
              </p>
              <div className="mt-6 h-[3px] w-[90px] bg-[#C52027]" />
            </div>
          </div>
          <div className="mt-12">
            <Gallery images={PORTFOLIO_GALLERY} />
          </div>
          <QuoteButtons className="mt-14" />
        </Container>
      </section>

      <CtaBand image="website-images-21.webp" />
    </>
  );
}
