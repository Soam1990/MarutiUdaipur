import React from "react";
import ServiceDetailPage from "@/components/site/ServiceDetailPage";

export default function Printing() {
  return <ServiceDetailPage slug="Printing" />;
}
