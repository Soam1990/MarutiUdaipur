import React from "react";

// Small self-contained SVG icon set (no extra packages needed).
const base = (size, className, children, viewBox = "0 0 24 24", extra = {}) => (
  <svg
    width={size}
    height={size}
    viewBox={viewBox}
    className={className}
    aria-hidden="true"
    {...extra}
  >
    {children}
  </svg>
);

const stroke = { fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };

export const InstagramIcon = ({ size = 16, className = "" }) =>
  base(size, className, (
    <g {...stroke}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor" />
    </g>
  ));

export const LinkedinIcon = ({ size = 16, className = "" }) =>
  base(size, className, (
    <path
      fill="currentColor"
      d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.22 0z"
    />
  ));

export const WhatsAppIcon = ({ size = 16, className = "" }) =>
  base(size, className, (
    <path
      fill="currentColor"
      d="M19.05 4.91A9.82 9.82 0 0 0 12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.91-7.01zm-7.01 15.24h-.01a8.23 8.23 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.21 8.21 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23a8.2 8.2 0 0 1 5.83 2.42 8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.22-8.24 8.22zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.78.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48a.92.92 0 0 0-.66.31c-.23.25-.87.85-.87 2.07s.89 2.4 1.01 2.56c.12.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.22-.16-.47-.28z"
    />
  ));

export const PhoneIcon = ({ size = 16, className = "" }) =>
  base(size, className, (
    <path
      {...stroke}
      d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"
    />
  ));

export const MailIcon = ({ size = 16, className = "" }) =>
  base(size, className, (
    <g {...stroke}>
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="m22 6-10 7L2 6" />
    </g>
  ));

export const ArrowRightIcon = ({ size = 16, className = "" }) =>
  base(size, className, <path {...stroke} d="M5 12h14M13 6l6 6-6 6" />);

export const ChevronDownIcon = ({ size = 14, className = "" }) =>
  base(size, className, <path {...stroke} d="m6 9 6 6 6-6" />);

export const MenuIcon = ({ size = 26, className = "" }) =>
  base(size, className, (
    <g fill="currentColor">
      {[5, 12, 19].map((y) => [5, 12, 19].map((x) => <circle key={`${x}-${y}`} cx={x} cy={y} r="2" />))}
    </g>
  ));

export const CloseIcon = ({ size = 22, className = "" }) =>
  base(size, className, <path {...stroke} d="M18 6 6 18M6 6l12 12" />);

export const PlusIcon = ({ size = 18, className = "" }) =>
  base(size, className, <path {...stroke} d="M12 5v14M5 12h14" />);

export const DotCircleIcon = ({ size = 12, className = "" }) =>
  base(size, className, (
    <g>
      <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="4" />
      <circle cx="12" cy="12" r="4" fill="currentColor" />
    </g>
  ));

export const ToolsIcon = ({ size = 28, className = "" }) =>
  base(size, className, (
    <path
      {...stroke}
      d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
    />
  ));

export const BadgeIcon = ({ size = 28, className = "" }) =>
  base(size, className, (
    <g {...stroke}>
      <circle cx="12" cy="8" r="6" />
      <path d="M15.48 12.89 17 22l-5-3-5 3 1.52-9.11" />
    </g>
  ));

export const TeamIcon = ({ size = 28, className = "" }) =>
  base(size, className, (
    <g {...stroke}>
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </g>
  ));
