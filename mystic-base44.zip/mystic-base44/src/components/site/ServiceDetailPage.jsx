import React from "react";
import { img } from "./siteData";
import { Container, QuoteButtons } from "./ui";
import { SERVICE_DETAILS } from "./serviceDetails";

function Blocks({ blocks, light = false }) {
  return (
    <div className={`space-y-3 text-[14px] leading-[1.75] ${light ? "text-white/95" : "text-[#5f5f5f]"}`}>
      {blocks.map((b, i) =>
        b.list ? (
          <ul key={i} className="grid gap-x-6 gap-y-1.5 pl-5 sm:grid-cols-2">
            {b.list.map((li) => (
              <li key={li} className="list-disc marker:text-[#C52027]">
                {li}
              </li>
            ))}
          </ul>
        ) : (
          <p key={i}>{b.p}</p>
        )
      )}
    </div>
  );
}

function FramedImage({ name, alt }) {
  return (
    <div className="rounded-[4px] bg-[#F45B63] p-[7px]">
      <img src={img(name)} alt={alt} loading="lazy" className="h-[280px] w-full object-cover sm:h-[360px]" />
    </div>
  );
}

function SplitSection({ section, index }) {
  const bg = index % 2 === 0 ? "bg-white" : "bg-[#FFF6F6]";
  const imageFirst = section.imageFirst ?? index % 2 === 0;
  return (
    <section className={`${bg} py-16 md:py-20`}>
      <Container>
        <div className={`grid items-center gap-10 ${section.image ? "md:grid-cols-2" : "mx-auto max-w-[900px]"}`}>
        {section.image && (
          <div className={imageFirst ? "md:order-1" : "md:order-2"}>
            <FramedImage name={section.image} alt={section.heading} />
          </div>
        )}
        <div className={imageFirst ? "md:order-2" : "md:order-1"}>
          <h2 className="ms-heading text-[26px] font-semibold capitalize leading-[1.2] tracking-[-0.5px] text-[#A3161C] md:text-[32px]">
            {section.heading}
          </h2>
          <div className="mt-5">
            <Blocks blocks={section.blocks} />
          </div>
        </div>
        </div>
      </Container>
    </section>
  );
}

function PairSection({ section }) {
  return (
    <section className="bg-white py-16 md:py-20">
      <Container className="grid gap-6 md:grid-cols-2">
        {section.items.map((item) => (
          <div key={item.heading} className="rounded-[14px] bg-[#FFF6F6] p-8 md:p-10">
            <h2 className="ms-heading text-[24px] font-semibold capitalize leading-[1.2] tracking-[-0.5px] text-[#A3161C] md:text-[28px]">
              {item.heading}
            </h2>
            <div className="mt-5">
              <Blocks blocks={item.blocks} />
            </div>
          </div>
        ))}
      </Container>
    </section>
  );
}

/** Renders one service detail page (Printing, Outdoor Advertising, …) from serviceDetails.js. */
export default function ServiceDetailPage({ slug }) {
  const data = SERVICE_DETAILS[slug];
  if (!data) return null;

  return (
    <>
      <section className="bg-white pb-10 pt-6 text-center">
        <Container>
          <h1 className="ms-heading text-[38px] font-semibold capitalize tracking-[-1px] text-[#C52027] md:text-[56px]">
            {data.title}
          </h1>
        </Container>
      </section>

      <section className="bg-[#C52027] py-16 md:py-20">
        <Container className="grid items-center gap-10 md:grid-cols-[1fr_0.95fr]">
          <div className="text-white">
            {data.eyebrow && (
              <div className="mb-4 text-[12px] font-semibold uppercase tracking-[0.12em] text-white/80">
                {data.eyebrow}
              </div>
            )}
            <h2 className="ms-heading text-[32px] font-semibold capitalize leading-[1.2] tracking-[-1px] md:text-[44px]">
              {data.heading}
            </h2>
            <div className="mt-6 space-y-3 text-[16px] leading-[1.7] text-white/95">
              {data.lead.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
          </div>
          <div className="rounded-[4px] bg-[#F45B63] p-[7px]">
            <img
              src={img(data.heroImage)}
              alt={data.title}
              className="h-[300px] w-full object-cover md:h-[380px]"
            />
          </div>
        </Container>
      </section>

      {data.introMore.length > 0 && (
        <section className="bg-white py-14">
          <Container>
            <div className="mx-auto max-w-[820px] space-y-3 text-center text-[15px] leading-[1.75] text-[#5f5f5f]">
              {data.introMore.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
          </Container>
        </section>
      )}

      {data.sections.map((s, i) =>
        s.type === "pair" ? (
          <PairSection key={i} section={s} />
        ) : (
          <SplitSection key={s.heading} section={s} index={i} />
        )
      )}

      <section className="bg-white py-14">
        <Container>
          <QuoteButtons />
        </Container>
      </section>

      <section className="bg-[#C52027] py-16 text-center md:py-20">
        <Container>
          <div className="mx-auto max-w-[860px] text-white">
          <h2 className="ms-heading text-[28px] font-semibold capitalize tracking-[-0.5px] md:text-[38px]">
            {data.closing.heading}
          </h2>
          <div className="mt-5 space-y-3 text-[15px] leading-[1.75] text-white/95">
            {data.closing.paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
          </div>
        </Container>
      </section>
    </>
  );
}
