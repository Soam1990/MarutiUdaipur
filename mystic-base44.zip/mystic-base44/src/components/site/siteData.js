// Shared site content and settings for the Mystic Solution website.
// Edit contact details, navigation and service cards here — every page reads from this file.

// Where the site images live. With Base44 GitHub sync, keep the images in /public/images
// and leave this as "/images/". If you host the images elsewhere (Base44 file upload, a CDN,
// an S3 bucket…), put the folder URL here, ending with a slash.
export const IMG_BASE = "/images/";
export const img = (name) => `${IMG_BASE}${name}`;

export const BRAND = {
  name: "Mystic Solution",
  legalName: "Maruti Mystic Solution",
  phoneDisplay: "+91- 072200 11004",
  phoneHref: "tel:+917220011004",
  email: "marutimysticsolution@gmail.com",
  whatsappHref: "https://api.whatsapp.com/send/?phone=917220011004",
  location: "Udaipur, Rajasthan",
  since: 2018,
  logo: "logo.webp",
};

export const SOCIALS = [
  { label: "Mystic Solution", short: "IG", type: "instagram", href: "https://www.instagram.com/mystic_solution" },
  { label: "Mystic Solution Digital", short: "IG", type: "instagram", href: "https://www.instagram.com/mysticdigitalco" },
  { label: "Mystic Solution", short: "Li", type: "linkedin", href: "https://www.linkedin.com/in/mrigank-oswal-1a454a77/" },
];

// `page` is the Base44 page name (file name in /pages) used with createPageUrl().
export const SERVICE_LINKS = [
  { label: "Printing", page: "Printing" },
  { label: "Outdoor Advertising", page: "OutdoorAdvertising" },
  { label: "Mobile Hoardings", page: "MobileHoardings" },
  { label: "Signage & In-Shop Branding", page: "SignageInShopBranding" },
  { label: "Corporate Events & Store Launches", page: "CorporateEventsStoreLaunches" },
  { label: "Newspaper Insertions", page: "NewspaperInsertions" },
  { label: "Digital Marketing", page: "DigitalMarketing" },
];

export const NAV = [
  { label: "Home", page: "Home" },
  { label: "Services", page: "Services", children: SERVICE_LINKS },
  { label: "Our Work", page: "OurWork" },
  { label: "About us", page: "AboutUs" },
  { label: "Contact", page: "Contact" },
];

export const FOOTER_LINKS = [
  { label: "Home", page: "Home" },
  { label: "Services", page: "Services" },
  { label: "Our Work", page: "OurWork" },
  { label: "About", page: "AboutUs" },
  { label: "Contact", page: "Contact" },
];

export const OUTDOOR_SERVICES = [
  {
    title: "Printing",
    text: "High-quality Solvent, Eco-Solvent, and UV printing for durable outdoor campaigns.",
    image: "9f76c140-ed74-4383-b157-99b54bbf94d7.webp",
    page: "Printing",
  },
  {
    title: "Outdoor Advertising",
    text: "Large-format advertising displays designed to maximize brand visibility in prime locations.",
    image: "796f54b6-ae19-42a7-9df3-dec9c364d6a4.webp",
    page: "OutdoorAdvertising",
  },
  {
    title: "Signage & In-Shop Branding",
    text: "Complete VM and in-store branding solutions to create a consistent and engaging customer experience.",
    image: "website-images-7.webp",
    servicesImage: "website-images-8.webp",
    page: "SignageInShopBranding",
  },
  {
    title: "Corporate Events & Store Launches",
    text: "Branding and promotional support to make events, openings, and launches more memorable.",
    image: "website-images-12.webp",
    page: "CorporateEventsStoreLaunches",
  },
  {
    title: "Mobile Hoardings",
    text: "Take your message across the city with moving outdoor advertising that reaches audiences on the go.",
    image: "website-images-5.webp",
    servicesImage: "website-images-10.webp",
    page: "MobileHoardings",
  },
  {
    title: "Newspaper Insertions",
    text: "Reach targeted local audiences through professionally designed newspaper inserts and promotional materials.",
    image: "3651b047-aa01-4083-8bde-4e1f1fe917cb.webp",
    page: "NewspaperInsertions",
  },
];

export const DIGITAL_SERVICES = [
  {
    title: "Social Media Marketing",
    text: "Build an active social presence with creative content, regular management, and audience engagement.",
    image: "pexels-photo-533446-533446.webp",
  },
  {
    title: "SEO",
    text: "Improve your website’s search visibility and attract relevant organic traffic with effective SEO strategies and optimization.",
    image: "pexels-photo-139387-139387-scaled.webp",
  },
  {
    title: "Website Designing",
    text: "Create professional, responsive websites that showcase your business and convert visitors into customers.",
    image: "ipad-mockup-apple-business-39559-39559-scaled.webp",
  },
  {
    title: "Logo Designing",
    text: "Build a memorable brand identity with a unique and professional logo designed around your business.",
    image: "360-f-394111545-jevjeehxey4pjvi070da3gh5nxu9chcl-1.webp",
  },
  {
    title: "Bulk SMS",
    text: "Connect directly with customers through promotional, transactional, and business communication campaigns.",
    image: "pexels-photo-1083931-1083931-scaled.webp",
  },
  {
    title: "Performance Marketing",
    text: "Data-driven advertising campaigns focused on reaching the right audience, generating leads, and delivering measurable business results.",
    image: "images-1-1.webp",
  },
];

export const CLIENT_LOGOS = [
  { name: "Mahindra", image: "mahindra-logo-png-seeklogo-509819.webp" },
  { name: "Reliance Digital", image: "reliance-digital-logo-png-seeklogo-373459.webp" },
  { name: "Reliance Smart", image: "reliance-smart-logo-png-seeklogo-373455.webp" },
  { name: "Reliance Trends", image: "reliance-trends-logo-vector-svg.webp" },
  { name: "Somany", image: "somany-vector-logo-logoshape.webp" },
  { name: "Suzuki", image: "suzuki-logo-2025-vertical.svg" },
];

export const HOME_GALLERY = [
  "website-images-2.webp",
  "website-images-1.webp",
  "website-images-11.webp",
  "website-images-6.webp",
  "website-images-4.webp",
  "website-images-19.webp",
];

export const PORTFOLIO_GALLERY = [
  "website-images-2.webp",
  "website-images-1.webp",
  "website-images-22.webp",
  "website-images-21.webp",
  "website-images-20.webp",
  "website-images-19.webp",
  "website-images-18.webp",
  "website-images-17.webp",
  "website-images-16.webp",
  "website-images-15.webp",
  "website-images-14.webp",
  "website-images-13.webp",
  "website-images-12.webp",
  "website-images-11.webp",
  "website-images-10.webp",
  "website-images-9.webp",
  "website-images-8.webp",
  "website-images-7.webp",
  "website-images-6.webp",
  "website-images-5.webp",
  "website-images-4.webp",
  "whatsapp-image-2026-06-25-at-9-31-31-am.webp",
  "website-images-3.webp",
];

export const CONTACT_SERVICE_OPTIONS = [
  "Printing",
  "Outdoor Advertising",
  "Signage & In-Shop Branding",
  "Corporate Events & Store Launches",
  "Mobile Hoardings",
  "Newspaper Insertions",
  "Social Media Marketing",
  "SEO",
  "Website Designing",
  "Logo Designing",
  "Bulk SMS",
  "Performance Marketing",
];
