// Content for the service detail pages, extracted from the original WordPress site.
// Block format: { p: "paragraph" } or { list: ["item", ...] }

export const SERVICE_DETAILS = {
  "Printing": {
    "title": "Printing Services",
    "eyebrow": "01. Printing",
    "heading": "Professional Printing for Every Business Requirement",
    "lead": [
      "High-quality printed communication is an essential part of a professional brand identity. From everyday corporate stationery to promotional materials, packaging, event collateral, and large-format graphics, we provide printing solutions tailored to your brand and application."
    ],
    "heroImage": "ccb2900e-2c0c-48e1-8e8d-2b8134ec2e0c.webp",
    "introMore": [
      "Whether you require a small quantity or a large-volume campaign, we help you select the appropriate material, size, finish, printing method, and format for the intended purpose."
    ],
    "sections": [
      {
        "heading": "Corporate & Business Printing",
        "blocks": [
          {
            "p": "Present your business professionally across everyday communication and corporate materials."
          },
          {
            "p": "Our corporate printing solutions include:"
          },
          {
            "list": [
              "Visiting Cards",
              "Letterheads",
              "Envelopes",
              "Business Forms",
              "Notepads",
              "Company Profiles",
              "Certificates",
              "Office Stationery",
              "Invoices and Business Documents"
            ]
          },
          {
            "p": "We ensure that your printed communication maintains a consistent appearance and reflects your brand identity."
          }
        ],
        "image": "a4e5c5fe-91f6-49ce-8288-22ae901be6b3.webp",
        "imageFirst": true
      },
      {
        "heading": "Marketing & Promotional Printing",
        "blocks": [
          {
            "p": "Transform your marketing designs into high-quality printed materials that communicate your products, services, offers, and campaigns effectively."
          },
          {
            "p": "We provide:"
          },
          {
            "list": [
              "Brochures",
              "Flyers",
              "Leaflets",
              "Posters",
              "Product Catalogues",
              "Promotional Inserts",
              "Marketing Collateral",
              "Promotional Cards"
            ]
          },
          {
            "p": "These are ideal for retail promotions, product campaigns, exhibitions, customer communication, and brand awareness activities."
          }
        ],
        "image": "website-images-13.webp",
        "imageFirst": false
      },
      {
        "heading": "Flex & Vinyl Printing",
        "blocks": [
          {
            "p": "Our Flex and Vinyl Printing solutions are designed for a wide range of indoor and outdoor advertising and branding applications."
          },
          {
            "p": "Flex is a versatile and economical material commonly used for large-format advertising, while vinyl provides a clean, durable, and professional finish for graphics, branding, signage, and promotional displays."
          },
          {
            "p": "We provide customized printing in different sizes according to the application, surface, location, and required display duration."
          },
          {
            "p": "Suitable for:"
          },
          {
            "list": [
              "Advertising Banners",
              "Outdoor Promotions",
              "Shop Branding",
              "Event Branding",
              "Wall Graphics",
              "Promotional Displays",
              "Hoarding Graphics",
              "Retail Campaigns",
              "Temporary & Long-Term Branding"
            ]
          }
        ],
        "image": "images.webp",
        "imageFirst": true
      },
      {
        "heading": "Large-Format Printing",
        "blocks": [
          {
            "p": "For campaigns that demand visibility, large-format printing allows your brand communication to make a stronger visual impact."
          },
          {
            "p": "Our large-format printing solutions include:"
          },
          {
            "list": [
              "Banners",
              "Posters",
              "Hoarding Graphics",
              "Event Displays",
              "Exhibition Graphics",
              "Promotional Displays",
              "Backdrops",
              "Campaign Graphics"
            ]
          },
          {
            "p": "These solutions are suitable for retail spaces, events, exhibitions, launches, outdoor campaigns, and promotional activities."
          }
        ],
        "image": "32c2948a-cdd1-40e8-9b7b-48644c21a2ef.webp",
        "imageFirst": false
      },
      {
        "type": "pair",
        "items": [
          {
            "heading": "Labels, Stickers & Product Branding",
            "blocks": [
              {
                "p": "Customized labels and stickers help businesses create a recognizable and professional product identity."
              },
              {
                "p": "Our solutions include:"
              },
              {
                "list": [
                  "Product Labels",
                  "Packaging Stickers",
                  "Brand Stickers",
                  "Promotional Stickers",
                  "Barcode & Information Labels",
                  "Custom Shapes & Sizes"
                ]
              },
              {
                "p": "These can be customized according to your product, packaging, branding, and application requirements."
              }
            ]
          },
          {
            "heading": "Packaging & Brand Collateral",
            "blocks": [
              {
                "p": "Professional packaging can strengthen the overall presentation of your product and create a consistent customer experience."
              },
              {
                "p": "We provide:"
              },
              {
                "list": [
                  "Product Packaging",
                  "Paper Bags",
                  "Tags & Hang Tags",
                  "Sleeves",
                  "Packaging Labels",
                  "Branded Inserts"
                ]
              }
            ]
          }
        ]
      },
      {
        "heading": "Event & Occasion Printing",
        "blocks": [
          {
            "p": "We provide customized printed materials for corporate events, exhibitions, product launches, store openings, celebrations, and special occasions."
          },
          {
            "p": "Solutions include:"
          },
          {
            "list": [
              "Invitations",
              "Event Cards",
              "Event Backdrops",
              "Standee Graphics",
              "Event Signage",
              "Promotional Materials",
              "Event Collateral"
            ]
          }
        ],
        "image": "website-images-13.webp",
        "imageFirst": true
      }
    ],
    "closing": {
      "heading": "Printing Tailored to Your Brand",
      "paragraphs": [
        "Every printing requirement is different. We help you select the right paper, material, size, finish, quantity, and printing solution based on how and where the final product will be used."
      ]
    }
  },
  "OutdoorAdvertising": {
    "title": "Outdoor Advertising",
    "eyebrow": null,
    "heading": "Put Your Brand Where People See It",
    "lead": [
      "Outdoor advertising helps businesses build strong visibility by placing their brand message in high-traffic, high-footfall, and strategically important locations."
    ],
    "heroImage": "website-images-6.webp",
    "introMore": [
      "At Maruti Mystic Solution, we provide outdoor advertising solutions ranging from individual advertising sites to larger multi-location outdoor campaigns.",
      "Our approach considers your target audience, campaign objective, location, visibility, duration, and budget to create an outdoor campaign suited to your requirements."
    ],
    "sections": [
      {
        "heading": "Hoardings",
        "blocks": [
          {
            "p": "Hoardings are large-format outdoor advertising displays positioned at prominent locations to provide continuous visibility to passing audiences."
          },
          {
            "p": "They are effective for businesses looking to build brand awareness, promote products or offers, launch new businesses or stores, and establish a stronger presence in a particular market."
          },
          {
            "p": "Ideal for:"
          },
          {
            "list": [
              "Brand Awareness",
              "Product Launches",
              "Retail Promotions",
              "Property Advertising",
              "Corporate Campaigns",
              "Seasonal Offers",
              "Local Market Campaigns"
            ]
          }
        ],
        "image": "website-images-21.webp",
        "imageFirst": true
      },
      {
        "heading": "Unipoles",
        "blocks": [
          {
            "p": "Unipoles are elevated advertising structures supported by a single pole, allowing the advertising display to remain highly visible from roads and surrounding areas."
          },
          {
            "p": "They are particularly suitable for major roads, highways, junctions, commercial areas, and locations where visibility from a distance is important."
          }
        ],
        "image": "796f54b6-ae19-42a7-9df3-dec9c364d6a4.webp",
        "imageFirst": false
      },
      {
        "heading": "Gantry Advertising",
        "blocks": [
          {
            "p": "Gantry advertising places large-format brand communication above or alongside major roads, providing high visibility to motorists, commuters, and other road users."
          },
          {
            "p": "Because of their prominent positioning, gantries can be effective for large-scale campaigns where reach, visibility, and brand recall are key objectives."
          }
        ],
        "image": "website-images-14.webp",
        "imageFirst": true
      },
      {
        "heading": "Outdoor Campaigns",
        "blocks": [
          {
            "p": "For brands requiring visibility across multiple locations, we can coordinate outdoor advertising campaigns using a combination of suitable advertising formats."
          },
          {
            "p": "A campaign can be planned according to:"
          },
          {
            "list": [
              "Target Locations",
              "Audience Profile",
              "Traffic & Footfall",
              "Campaign Duration",
              "Advertising Objective",
              "Number of Sites",
              "Campaign Budget"
            ]
          }
        ],
        "image": "image-2-1.webp",
        "imageFirst": false
      }
    ],
    "closing": {
      "heading": "Strategic Outdoor Visibility",
      "paragraphs": [
        "Effective outdoor advertising is about more than simply placing an advertisement. Location, visibility, audience movement, creative impact, frequency, and campaign duration all contribute to campaign performance.",
        "We help businesses plan outdoor campaigns that create consistent and meaningful brand visibility."
      ]
    }
  },
  "SignageInShopBranding": {
    "title": "Signage & In-Shop Branding",
    "eyebrow": null,
    "heading": "Turn Your Business Space Into a Brand Experience",
    "lead": [
      "Your physical business space is one of the most important places where customers interact with your brand."
    ],
    "heroImage": "website-images-16.webp",
    "introMore": [
      "Professional signage and in-shop branding help customers identify your business, navigate the space, understand your offerings, and experience your brand consistently.",
      "We provide signage and complete visual branding solutions for retail stores, showrooms, offices, restaurants, commercial establishments, and other business spaces."
    ],
    "sections": [
      {
        "heading": "ACP Boards",
        "blocks": [
          {
            "p": "ACP (Aluminium Composite Panel) boards offer a clean, durable, and professional surface for interior and exterior business signage."
          },
          {
            "p": "They are commonly used for:"
          },
          {
            "list": [
              "Shop Sign Boards",
              "Office Signage",
              "Showroom Signage",
              "Corporate Signage",
              "Building Signage",
              "Exterior Branding"
            ]
          }
        ],
        "image": "website-images-11.webp",
        "imageFirst": true
      },
      {
        "heading": "Acrylic Letters & 3D Branding",
        "blocks": [
          {
            "p": "Acrylic letters create a dimensional and premium appearance for business names, logos, and brand communication."
          },
          {
            "p": "They can be used for:"
          },
          {
            "list": [
              "3D Brand Names",
              "Logo Letters",
              "Reception Branding",
              "Office Signage",
              "Retail Signage",
              "Showroom Branding",
              "Feature Walls"
            ]
          },
          {
            "p": "Different finishes and styles can be selected to complement the brand’s visual identity and physical environment."
          }
        ],
        "image": "website-images-3.webp",
        "imageFirst": false
      },
      {
        "heading": "Complete In-Shop Visual Branding",
        "blocks": [
          {
            "p": "We provide end-to-end visual branding solutions designed to create a consistent brand experience throughout your store or commercial space."
          },
          {
            "p": "This can include:"
          },
          {
            "list": [
              "Entrance Branding",
              "Wall Graphics",
              "Counter Branding",
              "Product Displays",
              "Window Graphics",
              "Promotional Displays",
              "Shelf Branding",
              "Point-of-Sale Branding",
              "Directional Signage",
              "Information Boards",
              "In-Store Promotional Materials"
            ]
          }
        ],
        "image": "website-images-7.webp",
        "imageFirst": true
      }
    ],
    "closing": {
      "heading": "Creating a Consistent Brand Environment",
      "paragraphs": [
        "We consider your brand identity, colour palette, messaging, customer movement, available space, and business objectives to develop branding that works cohesively across the entire premises.",
        "From the entrance to the checkout counter, every visual element can contribute to a stronger and more recognizable brand experience."
      ]
    }
  },
  "CorporateEventsStoreLaunches": {
    "title": "Corporate Events & Store Launches",
    "eyebrow": null,
    "heading": "Make Every Launch and Event a Branded Experience",
    "lead": [
      "Corporate events and store launches are important opportunities to create visibility, engage audiences, and introduce your brand in a professional manner."
    ],
    "heroImage": "website-images-12.webp",
    "introMore": [
      "We provide event and launch branding solutions that help transform venues and business spaces into cohesive branded environments."
    ],
    "sections": [
      {
        "heading": "Corporate Event Branding",
        "blocks": [
          {
            "p": "We support corporate events with customized branding and visual communication solutions."
          },
          {
            "p": "These may include:"
          },
          {
            "list": [
              "Event Backdrops",
              "Stage Branding",
              "Standee Displays",
              "Event Signage",
              "Venue Branding",
              "Directional Signage",
              "Promotional Displays",
              "Event Collateral",
              "Photo & Media Backdrops"
            ]
          }
        ],
        "image": "whatsapp-image-2026-06-25-at-9-31-31-am.webp",
        "imageFirst": true
      },
      {
        "heading": "Store Launches",
        "blocks": [
          {
            "p": "A store launch is an opportunity to create excitement and introduce your business to the local market."
          },
          {
            "p": "We provide branding and promotional support for:"
          },
          {
            "list": [
              "Store Opening Branding",
              "Launch Backdrops",
              "Outdoor Promotional Displays",
              "Standee Graphics",
              "Directional Signage",
              "Promotional Materials",
              "In-Store Branding",
              "Launch-Day Visuals"
            ]
          }
        ],
        "image": "image-5-1.webp",
        "imageFirst": false
      },
      {
        "heading": "Brand Activations & Promotional Events",
        "blocks": [
          {
            "p": "For promotional activities and brand activations, we help create visual elements that make the campaign recognizable and engaging."
          },
          {
            "p": "This can include venue branding, promotional displays, campaign graphics, signage, and other physical brand communication."
          }
        ],
        "image": "image-9.webp",
        "imageFirst": true
      }
    ],
    "closing": {
      "heading": "From Planning to Execution",
      "paragraphs": [
        "We coordinate the required branding elements to ensure that your event or launch maintains a consistent and professional visual identity from preparation through execution."
      ]
    }
  },
  "MobileHoardings": {
    "title": "Mobile Hoarding",
    "eyebrow": null,
    "heading": "Take Your Brand Message Across the City",
    "lead": [
      "Mobile hoardings provide a flexible outdoor advertising solution that takes your brand message directly to different areas and audiences."
    ],
    "heroImage": "website-images-5.webp",
    "introMore": [
      "Unlike fixed advertising formats, mobile campaigns can cover multiple locations during the campaign period, making them particularly useful for local promotions, store launches, product campaigns, events, and time-sensitive advertising."
    ],
    "sections": [
      {
        "heading": "Truck Advertising",
        "blocks": [
          {
            "p": "Large advertising displays placed on trucks provide extensive branding space and can deliver high visibility across multiple routes and locations."
          },
          {
            "p": "Truck advertising is suitable for businesses looking to achieve broad geographic exposure while maintaining a strong visual presence."
          }
        ],
        "image": "castrol.webp",
        "imageFirst": true
      },
      {
        "heading": "Bus Advertising",
        "blocks": [
          {
            "p": "Bus advertising allows brands to reach audiences throughout busy urban routes and high-traffic areas."
          },
          {
            "p": "Depending on the campaign requirement, branding can be placed across different areas of the bus to maximize visibility among commuters, pedestrians, and motorists."
          }
        ],
        "image": "download-1.webp",
        "imageFirst": false
      },
      {
        "heading": "E-Rickshaw Advertising",
        "blocks": [
          {
            "p": "E-rickshaw advertising provides a cost-effective way to reach local audiences across neighbourhoods, markets, commercial areas, and residential zones."
          },
          {
            "p": "It can be particularly useful for businesses targeting specific local markets or running city-level promotional campaigns."
          }
        ],
        "image": "website-images-1.webp",
        "imageFirst": true
      },
      {
        "heading": "Canter Advertising",
        "blocks": [
          {
            "p": "Canter advertising provides a larger mobile advertising surface and is suitable for campaigns that require substantial branding space and movement across multiple locations."
          },
          {
            "p": "It can be used for product launches, retail campaigns, events, local promotions, and high-visibility brand campaigns."
          }
        ],
        "image": "image-10.webp",
        "imageFirst": false
      },
      {
        "heading": "Auto Advertising",
        "blocks": [
          {
            "p": "Auto advertising allows brands to take their message directly through busy local markets, roads, commercial areas, and residential neighbourhoods."
          },
          {
            "p": "It is suitable for targeted local campaigns where repeated visibility across specific areas is important."
          }
        ],
        "image": "banner-8.webp",
        "imageFirst": true
      }
    ],
    "closing": {
      "heading": "Flexible & Location-Focused Campaigns",
      "paragraphs": [
        "Mobile advertising can be planned around target areas, routes, campaign duration, vehicle type, branding requirements, and audience profile.",
        "This makes it a flexible addition to both local and larger outdoor advertising campaigns."
      ]
    }
  },
  "NewspaperInsertions": {
    "title": "Newspaper Insertion",
    "eyebrow": null,
    "heading": "Direct Print Reach to Your Target Audience",
    "lead": [
      "Newspaper insertions provide businesses with an effective way to distribute promotional communication directly to newspaper readers."
    ],
    "heroImage": "newspaper-insert.webp",
    "introMore": [
      "Instead of placing a conventional advertisement within the newspaper, an insertion allows a separate printed piece—such as a flyer, leaflet, brochure, or promotional offer—to be inserted into the newspaper and delivered with it."
    ],
    "sections": [
      {
        "heading": "Promotional Inserts",
        "blocks": [
          {
            "p": "Newspaper inserts can be used to communicate detailed information that may require more space than a standard newspaper advertisement."
          },
          {
            "p": "They are suitable for:"
          },
          {
            "list": [
              "Product Launches",
              "Retail Offers",
              "Store Openings",
              "Property Promotions",
              "Seasonal Campaigns",
              "Promotional Offers",
              "Public Announcements",
              "Local Brand Campaigns"
            ]
          }
        ],
        "image": "image-15-1.webp",
        "imageFirst": true
      },
      {
        "heading": "Targeted Newspaper Campaigns",
        "blocks": [
          {
            "p": "The effectiveness of a newspaper insertion campaign depends on selecting the right publication, edition, geographic area, audience, campaign size, and timing."
          },
          {
            "p": "We assist businesses in planning and coordinating insertion campaigns according to their target market and communication objectives."
          }
        ],
        "image": "3651b047-aa01-4083-8bde-4e1f1fe917cb.webp",
        "imageFirst": false
      },
      {
        "heading": "Local & Regional Reach",
        "blocks": [
          {
            "p": "Newspaper insertions can be particularly useful for businesses targeting specific cities, neighbourhoods, or regional markets."
          },
          {
            "p": "By selecting relevant newspaper editions and distribution areas, campaigns can be planned to reach audiences in locations that matter most to the business."
          }
        ]
      }
    ],
    "closing": {
      "heading": "An Effective Addition to Your Marketing Mix",
      "paragraphs": [
        "Newspaper insertions can work independently or alongside outdoor advertising, printing, retail branding, and other promotional activities to create broader campaign visibility."
      ]
    }
  }
};
