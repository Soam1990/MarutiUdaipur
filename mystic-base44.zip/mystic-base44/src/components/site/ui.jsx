import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { img, BRAND } from "./siteData";
import { DotCircleIcon, MailIcon, WhatsAppIcon, ArrowRightIcon, CloseIcon } from "./Icons";

// Brand palette (from the original Elementor kit)
export const C = {
  red: "#C52027",
  pink: "#F45B63",
  heading: "#272727",
  text: "#737373",
  bgLight: "#F6F7F7",
  footer: "#F6F5FD",
};

export function Container({ className = "", children }) {
  return <div className={`mx-auto w-full max-w-[1280px] px-5 ${className}`}>{children}</div>;
}

export function SectionTag({ children, center = false, light = false }) {
  return (
    <div
      className={`flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.12em] ${
        center ? "justify-center" : ""
      } ${light ? "text-white/80" : "text-[#737373]"}`}
    >
      <DotCircleIcon size={11} className={light ? "text-white" : "text-[#C52027]"} />
      <span>{children}</span>
    </div>
  );
}

const variants = {
  red: "bg-[#C52027] text-white hover:bg-[#a51a20]",
  dark: "bg-black text-white hover:bg-[#272727]",
  pink: "bg-[#F45B63] text-[#272727] hover:bg-[#C52027] hover:text-white",
  white: "bg-white text-[#C52027] hover:bg-[#272727] hover:text-white",
  outline: "border border-[#C52027] text-[#C52027] hover:bg-[#C52027] hover:text-white",
  whatsapp: "bg-[#25D366] text-white hover:bg-[#1da851]",
};

/** Pill button. Pass `page` (Base44 page name) for internal links or `href` for external/tel links. */
export function PillButton({ page, href, variant = "red", size = "md", icon, children, className = "", onClick, type }) {
  const sizes = { sm: "px-5 py-2.5 text-[13px]", md: "px-7 py-3.5 text-[14px]", lg: "px-8 py-4 text-[15px]" };
  const cls = `inline-flex items-center justify-center gap-2 rounded-full font-semibold underline underline-offset-2 shadow-[0_5px_10px_rgba(0,0,0,0.12)] transition-colors duration-200 ${sizes[size]} ${variants[variant]} ${className}`;
  const content = (
    <>
      {icon}
      <span>{children}</span>
    </>
  );
  if (page) return <Link to={createPageUrl(page)} className={cls}>{content}</Link>;
  if (href) {
    const external = href.startsWith("http");
    return (
      <a href={href} className={cls} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>
        {content}
      </a>
    );
  }
  return <button type={type || "button"} onClick={onClick} className={cls}>{content}</button>;
}

export function QuoteButtons({ className = "" }) {
  return (
    <div className={`flex flex-wrap items-center justify-center gap-4 ${className}`}>
      <PillButton page="Contact" variant="red" icon={<MailIcon size={16} />}>
        Get Quote on Mail
      </PillButton>
      <PillButton href={BRAND.whatsappHref} variant="whatsapp" icon={<WhatsAppIcon size={17} />}>
        Get Quote on WhatsApp
      </PillButton>
    </div>
  );
}

export function ServiceGroupHeading({ title, subtitle }) {
  return (
    <div className="text-center">
      <h2 className="ms-heading text-[30px] font-semibold uppercase tracking-[-1px] text-[#272727] md:text-[38px]">
        {title}
      </h2>
      <p className="mt-2 text-[12px] font-semibold uppercase tracking-[0.12em] text-[#737373]">{subtitle}</p>
    </div>
  );
}

/** Rounded banner used at the top of inner pages (About, Contact, Our Work, services). */
export function PageHero({ tag, title, image }) {
  return (
    <div className="px-3 pt-2 md:px-5">
      <div
        className="relative mx-auto flex min-h-[300px] max-w-[1340px] items-center overflow-hidden rounded-[24px] bg-cover bg-center md:min-h-[400px]"
        style={{ backgroundImage: image ? `url(${img(image)})` : undefined, backgroundColor: C.red }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#C52027]/20 via-[#C52027]/55 to-[#C52027]/90" />
        <div className="relative ml-auto w-full px-6 py-12 md:w-[48%] md:pr-12">
          <div className="border-l-2 border-white/90 pl-5">
            {tag && (
              <span className="mb-4 inline-block rounded-full bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.1em] text-[#C52027]">
                {tag}
              </span>
            )}
            <h1 className="ms-heading text-[30px] font-semibold capitalize leading-[1.2] tracking-[-0.5px] text-white md:text-[38px]">
              {title}
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
}

/** Circular "YEARS OF EXPERIENCE" badge with the rotating text ring. */
export function ExperienceBadge({ years = 8, className = "" }) {
  const text = "YEARS OF EXPERIENCE • YEARS OF EXPERIENCE • YEARS OF EXPERIENCE • ";
  // `className` positions the badge (e.g. "absolute -left-4 -top-4"); the inner box is the relative frame.
  return (
    <div className={className}>
    <div className="relative h-[150px] w-[150px] rounded-full bg-[#C52027] shadow-xl">
      <svg viewBox="0 0 200 200" className="ms-spin absolute inset-0 h-full w-full">
        <defs>
          <path id="ms-circle" d="M100,100 m-78,0 a78,78 0 1,1 156,0 a78,78 0 1,1 -156,0" />
        </defs>
        <text fill="#fff" fontSize="12.5" fontWeight="600">
          <textPath href="#ms-circle" textLength="486" lengthAdjust="spacing">
            {text}
          </textPath>
        </text>
      </svg>
      <div className="ms-heading absolute inset-0 flex items-center justify-center text-[44px] font-semibold text-white">
        <CountUp to={years} />+
      </div>
    </div>
    </div>
  );
}

export function CountUp({ to, duration = 1500 }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf;
    const start = performance.now();
    const tick = (t) => {
      const p = Math.min(1, (t - start) / duration);
      setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);
  return <>{n}</>;
}

/** Card with photo on top and a white text panel overlapping its bottom edge (service cards). */
export function ImageBoxCard({ title, text, image, page }) {
  const inner = (
    <div className="group flex h-full flex-col">
      <div className="aspect-square overflow-hidden rounded-t-[6px]">
        <img
          src={img(image)}
          alt={title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="relative z-10 mx-3 -mt-3 flex flex-1 flex-col items-center rounded-[10px] bg-white px-6 pb-7 pt-5 text-center shadow-[0_10px_30px_rgba(0,0,0,0.08)]">
        <h3 className="ms-heading text-[15px] font-semibold text-[#272727] transition-colors group-hover:text-[#C52027]">
          {title}
        </h3>
        <p className="mt-3 text-[13px] leading-[1.6] text-[#737373]">{text}</p>
        {page && (
          <span className="mt-4 inline-flex h-8 w-8 items-center justify-center rounded-full bg-[#F45B63] text-white opacity-0 transition-opacity group-hover:opacity-100">
            <ArrowRightIcon size={15} />
          </span>
        )}
      </div>
    </div>
  );
  return page ? (
    <Link to={createPageUrl(page)} className="block h-full">
      {inner}
    </Link>
  ) : (
    inner
  );
}

/** Full-width photo band with a heading, text and button on the right. */
export function CtaBand({ image = "website-images-4.webp" }) {
  return (
    <section
      className="relative overflow-hidden bg-cover bg-center"
      style={{ backgroundImage: `url(${img(image)})` }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-black/10 via-black/30 to-black/75" />
      <Container className="relative flex min-h-[460px] items-center justify-end py-20">
        <div className="max-w-[520px] text-white">
          <h2 className="ms-heading text-[30px] font-semibold capitalize leading-[1.2] tracking-[-1px] md:text-[40px]">
            Making Your Brand Visible. Making Your Business Grow.
          </h2>
          <p className="mt-5 text-[14px] leading-[1.7] text-white/90">
            From impactful outdoor advertising and professional printing to creative branding and digital marketing,
            we combine ideas and execution to help your business get noticed and grow.
          </p>
          <PillButton page="Contact" variant="pink" size="sm" className="mt-7">
            Contact us
          </PillButton>
        </div>
      </Container>
    </section>
  );
}

/** Image grid that opens a full-screen viewer on click. */
export function Gallery({ images, columns = 3 }) {
  const [open, setOpen] = useState(-1);
  useEffect(() => {
    if (open < 0) return;
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(-1);
      if (e.key === "ArrowRight") setOpen((i) => (i + 1) % images.length);
      if (e.key === "ArrowLeft") setOpen((i) => (i - 1 + images.length) % images.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, images.length]);

  const grid = columns === 3 ? "sm:grid-cols-2 lg:grid-cols-3" : "sm:grid-cols-2";
  return (
    <>
      <div className={`grid grid-cols-1 gap-5 ${grid}`}>
        {images.map((name, i) => (
          <button
            key={name + i}
            type="button"
            onClick={() => setOpen(i)}
            className="group block aspect-[4/3] overflow-hidden rounded-[12px] bg-[#F6F7F7]"
            aria-label={`Open project image ${i + 1}`}
          >
            <img
              src={img(name)}
              alt={`Mystic Solution project ${i + 1}`}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          </button>
        ))}
      </div>
      {open >= 0 && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4"
          onClick={() => setOpen(-1)}
          role="dialog"
          aria-modal="true"
        >
          <button
            type="button"
            className="absolute right-5 top-5 rounded-full bg-white/10 p-2 text-white hover:bg-white/20"
            aria-label="Close"
          >
            <CloseIcon />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setOpen((i) => (i - 1 + images.length) % images.length);
            }}
            className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 px-4 py-3 text-2xl text-white hover:bg-white/20"
            aria-label="Previous image"
          >
            ‹
          </button>
          <img
            src={img(images[open])}
            alt=""
            className="max-h-[88vh] max-w-[92vw] rounded-lg object-contain"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setOpen((i) => (i + 1) % images.length);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 px-4 py-3 text-2xl text-white hover:bg-white/20"
            aria-label="Next image"
          >
            ›
          </button>
        </div>
      )}
    </>
  );
}
